package net.swin.chunkhighlighter;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.*;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.*;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.*;
import net.minecraft.world.chunk.Chunk;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Minecraft 1.21.x Fabric Client Mod
 * Chunk Highlighter with icons + counters
 */
public class ChunkHighlighterMod implements ClientModInitializer {

    public static boolean enabled = true;

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ChunkRenderer::render);
        Keybinds.init();
    }

    static class ChunkData {
        int spawner, chest, enderChest, shulker, redstone;
        boolean hasAnything() { return spawner + chest + enderChest + shulker + redstone > 0; }
        boolean hasSpawner() { return spawner > 0; }
    }

    static class ChunkScanner {
        static final Map<ChunkPos, ChunkData> DATA = new HashMap<>();
        static void scan(Chunk chunk) {
            ChunkPos pos = chunk.getPos();
            if (DATA.containsKey(pos)) return;

            ChunkData d = new ChunkData();
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                if (be instanceof MobSpawnerBlockEntity) d.spawner++;
                if (be instanceof ChestBlockEntity) d.chest++;
                if (be instanceof EnderChestBlockEntity) d.enderChest++;
                if (be instanceof ShulkerBoxBlockEntity) d.shulker++;
            }

            for (int x = 0; x < 16; x++)
                for (int y = chunk.getBottomY(); y < chunk.getTopY(); y++)
                    for (int z = 0; z < 16; z++) {
                        Block b = chunk.getBlockState(new BlockPos(x, y, z)).getBlock();
                        if (b instanceof RedstoneWireBlock ||
                            b instanceof PistonBlock ||
                            b instanceof ObserverBlock ||
                            b instanceof RepeaterBlock ||
                            b instanceof ComparatorBlock ||
                            b instanceof DispenserBlock ||
                            b instanceof DropperBlock) d.redstone++;
                    }

            if (d.hasAnything()) DATA.put(pos, d);
        }
    }

    static class ChunkRenderer {
        static void render(WorldRenderContext ctx) {
            if (!enabled) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null || mc.player == null) return;

            Vec3d cam = ctx.camera().getPos();
            MatrixStack matrices = ctx.matrixStack();
            ItemRenderer itemRenderer = mc.getItemRenderer();
            TextRenderer textRenderer = mc.textRenderer;

            RenderSystem.disableDepthTest();
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);

            BufferBuilder buffer = Tessellator.getInstance().getBuffer();
            buffer.begin(VertexFormat.DrawMode.LINES, VertexFormats.POSITION_COLOR);

            ChunkScanner.DATA.forEach((pos, data) -> {
                int y = mc.world.getTopY() - 1;
                float r = data.hasSpawner() ? 0.7f : 0f;
                float g = data.hasSpawner() ? 0f : 1f;
                float b = data.hasSpawner() ? 0.9f : 0f;

                double x1 = pos.getStartX() - cam.x;
                double z1 = pos.getStartZ() - cam.z;
                double x2 = pos.getEndX() + 1 - cam.x;
                double z2 = pos.getEndZ() + 1 - cam.z;
                double yy = y - cam.y;

                drawChunkBox(buffer, x1, yy, z1, x2, yy, z2, r, g, b);
            });

            BufferRenderer.drawWithGlobalProgram(buffer.end());

            ChunkScanner.DATA.forEach((pos, data) -> {
                int y = mc.world.getTopY() + 2;
                double cx = pos.getStartX() + 8 - cam.x;
                double cz = pos.getStartZ() + 8 - cam.z;
                double cy = y - cam.y;

                matrices.push();
                matrices.translate(cx, cy, cz);
                matrices.multiply(mc.getEntityRenderDispatcher().getRotation());
                matrices.scale(-0.5f, -0.5f, 0.5f);

                int i = 0;
                i = draw(itemRenderer, textRenderer, matrices, Items.SPAWNER, data.spawner, i);
                i = draw(itemRenderer, textRenderer, matrices, Items.CHEST, data.chest, i);
                i = draw(itemRenderer, textRenderer, matrices, Items.ENDER_CHEST, data.enderChest, i);
                i = draw(itemRenderer, textRenderer, matrices, Items.SHULKER_BOX, data.shulker, i);
                i = draw(itemRenderer, textRenderer, matrices, Items.REDSTONE, data.redstone, i);

                matrices.pop();
            });

            RenderSystem.enableDepthTest();
        }

        static int draw(ItemRenderer ir, TextRenderer tr, MatrixStack m, Item item, int count, int index) {
            if (count <= 0) return index;
            m.push();
            m.translate(index * 20, 0, 0);
            ir.renderInGui(item.getDefaultStack(), 0, 0);
            m.translate(12, 10, 1);
            m.scale(0.7f, 0.7f, 0.7f);
            tr.draw(Text.literal("×" + count), 0, 0, 0xFFFFFF, true,
                m.peek().getPositionMatrix(),
                VertexConsumerProvider.immediate(Tessellator.getInstance().getBuffer()),
                TextRenderer.TextLayerType.NORMAL, 0, 15728880);
            m.pop();
            return index + 1;
        }

        static void drawChunkBox(BufferBuilder b,
                                 double x1, double y, double z1,
                                 double x2, double y2, double z2,
                                 float r, float g, float bl) {
            b.vertex(x1, y, z1).color(r, g, bl, 1).next();
            b.vertex(x2, y, z1).color(r, g, bl, 1).next();
            b.vertex(x2, y, z2).color(r, g, bl, 1).next();
            b.vertex(x1, y, z2).color(r, g, bl, 1).next();
            b.vertex(x1, y, z1).color(r, g, bl, 1).next();
        }
    }

    static class Keybinds {
        static void init() {
            KeyBinding toggle = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Toggle Chunk Highlighter", GLFW.GLFW_KEY_H, "Chunk Highlighter")
            );
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                while (toggle.wasPressed()) enabled = !enabled;
            });
        }
    }
}
